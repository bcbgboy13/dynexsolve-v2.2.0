#!/usr/bin/env bash
# This file will contain functions related to gathering stats and displaying it for agent
# Agent will have to call mmp-stats.sh which will contain triggers for configuration files and etc.
# Do not add anything static in this file
GPU_COUNT=$1
LOG_FILE=$2
cd `dirname $0`
. mmp-external.conf

get_cards_order(){
    # index is global
    index=$(echo `seq -s ' ' 0 $((GPU_COUNT - 1))`)
}

get_cards_hashes(){
    # hash is global
    hash=''
    for (( i=0; i < ${GPU_COUNT}; i++ )); do
        hash[$i]=''
        local MHS=$(cat $LOG_FILE | grep -E "\bGPU ${i}\b" |tail -n1 |cut -d "|" -f4 |grep -E -o "[0-9_.]+")
        if [[ -z "$MHS" ]]; then
            local MHS="0"
        fi
        hash[$i]=`echo $MHS`
    done
}

get_miner_shares_ac(){
    local ac=0
    local ac=$(cat $LOG_FILE | grep -E "\bSHARE ACCEPTED BY POOL\b" |tail -n1 |cut -d "(" -f2 |cut -d "/" -f1|grep -E -o "[0-9_.]+")
    echo $ac
}

get_miner_shares_rj(){
    local rj=0
    local rj=$(cat $LOG_FILE | grep -E "\bSHARE ACCEPTED BY POOL\b" |tail -n1 |cut -d "(" -f2 |cut -d "/" -f2|cut -d ")" -f1|grep -E -o "[0-9_.]+")
    echo $rj
}

get_miner_stats() {
    stats=
    # Actual data getting
    local index=
    get_cards_order				# gpu order array
    local hash=
    get_cards_hashes                        # hashes array
    local units='hs'                    # hashes units
    # A/R shares by pool
    local ac=$(get_miner_shares_ac)
    local rj=$(get_miner_shares_rj)

    # make JSON
    stats=$(jq -nc \
            --argjson index "`echo ${index[@]} | tr " " "\n" | jq -cs '.'`" \
            --argjson hash "`echo ${hash[@]} | tr " " "\n" | jq -cs '.'`" \
            --arg units "$units" \
            --arg ac "$ac" --arg rj "$rj" \
            --arg miner_version "$EXTERNAL_VERSION" \
            --arg miner_name "$EXTERNAL_NAME" \
        '{$index, $hash, $units, ar: [$ac, $rj], miner_name: $miner_name, miner_version: $miner_version}')
    # total hashrate in khs
    echo $stats
}
get_miner_stats $GPU_COUNT $LOG_FILE

